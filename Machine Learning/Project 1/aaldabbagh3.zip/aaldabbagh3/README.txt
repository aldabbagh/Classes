
CS 7641: Machine Learning
_________________________
aaldabbagh3 - Assigment 1
_________________________

	Introduction:

	This readme file serves as a simple guide to run the tests I used in my assigment. For python files you will need all dependencies such as sklearn, 

	numpy, matplotlib or any other imported library that is not part of python 2.7. Missing libraries can be installed using the command in cmd:
						
									pip install <library name>


	Also, make sure the data files 'letterRecognition.csv' and 'Wdbc.csv' are present. 
	___________________________________________________________________________________________________________________________________________________

	
	In the code folder, there are files pertaining to each algorithm and in order to run them, you need to follow the steps under each algorithm below:

	- SVM:
		- is a python file named 'SupportVectorTests.py'
		- to select the data set, go to line number 10 and assign dataSet a string of either "Cancer" or "Character"
		- Run the program
		- Results will be printed on the screen. Whereas,graphs are saved to a created folder named 'SVM' in the same directory

	- weighted Knn:
		- is a python file named 'weightedKNN.py'
		- to select the data set, go to line number 8 and assign dataSet a string of either "Cancer" or "Character"
		- Run the program
		- Results will be printed on the screen. Whereas,graphs are saved to a created folder named 'weightedKNN' in the same directory

	- Boosting:
		- is a python file named 'Boosting Tests.py'
		- to select the data set, go to line number 9 and assign dataSet a string of either "Cancer" or "Character"
		- Run the program
		- Results will be printed on the screen. Whereas,graphs are saved to a created folder named 'Boosting' in the same directory

	- Decision Trees:
		- is a python file named 'Decision Tree Tests.py'
		- to select the data set, go to line number 9 and assign dataSet a string of either "Cancer" or "Character"
		- Run the program
		- Results will be printed on the screen. Whereas,graphs are saved to a created folder named 'decisionTree' in the same directory
		- Pruning can be done on weka using the smartCart algorithm with parameters chosen by sklearn

	- KNN:
		- is a python file named 'SupportVectorTests.py'
		- to select the data set, go to line number 8 and assign dataSet a string of either "Cancer" or "Character"
		- Run the program
		- Results will be printed on the screen. Whereas,graphs are saved to a created folder named 'KNN' in the same directory

	- Neural Networks:
		- is a MATLAB file named 'NeuralNetTest.m'
		- Load 'Data set file.mat' into matlab by dragging it and dropping it in the console window of MATLAB
		- Open file NeuralNetTest.m
		- to select the data set, go to line number 10 and assign 'x' a value of either (CharacterNotNormalizedData') or 
		  (CancerNormalizedData') the appsotrophe at the end is important as you are taking the transpose
	
		- Go to line 11:
				- If you chose Character data, assign 't' a value of (CharacterEndcodedOutput')
				- If you chose Character data, assign 't' a value of (CancerOutput')
		- To choose network size go to line 22, edit the array such that each element corrosponds to number of units in layer. Example:
		  [10] is one layer with 10 units. Whereas, [4 5] is two layers where the first has 4 units and the second has 5.
		- Run the program
		- Results will be printed on the screen.


     



	*NOTE: In order for the code to function properly, do not remove any of the files from the directory. Also, please make sure to create the output 
	 directories for Each of the algorithms as mentioned above.




















